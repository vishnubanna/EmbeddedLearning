#ifndef _INIT_H_
#define _INIT_H_


/****************************
 * total memory: 1108 + 400
 ****************************/
#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include "midi.h"
#include <math.h>
/******************************
 * uart requirements
 ******************************/

void init_square();
void init_sin();
void init_hybrid();




#endif
