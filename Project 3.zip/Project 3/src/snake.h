#ifndef __SNAKE_H__
#define __SNAKE_H__

void splash(void);
void animate(void);

void freeze(void);
int  get_seed(void);

#endif /* __SNAKE_H__ */
